#Estrutura de Dados:
from console_logging.console import Console
console = Console()
  
class Filas:
    def __init__(self):
        console.log("START")
        self.__fila = []

    def insere(self, value):
        console.log("insere " + str(value))
        self.__fila.append(value)

    def remove(self):
        console.log("POP DATA")
        return self.__fila.pop(0)

    def show(self):
        console.success(f'Queue: {self.__fila}')

class Pilha:
    def __init__(self):
        console.log("START PILHAS ")
        self.__pilha = []
        
    def push(self, value):
        console.log("PUSH " + str(value))
        self.__pilha.append(value)
        
    def pop(self):
        console.info("POP")
        return self.__pilha.pop()
        
    def show(self):
        console.success("Pilha: {}".format(self.__pilha))


class Node:
    def __init__(self, value, arquivo ,proximo=None):
        self.__value = value
        self.arq = arquivo
        self.proximo = proximo

    @property
    def value(self):
        return self.__value

class ListaEncadeadaSimples:
    def __init__(self):
        self.__main_node = None

    def append(self, value,arquivo):
        if self.__main_node is None:
            self.__main_node = Node(value,arquivo)
            return

        proximo_node = self.__main_node
        while proximo_node.proximo is not None:
            proximo_node = proximo_node.proximo
        proximo_node.proximo = Node(value,arquivo)

    def remove(self, value):
        if self.__main_node is None:
            return

        left_node = None
        proximo_node = self.__main_node

        if proximo_node.value == value:
            self.__main_node = proximo_node

        while True:
            left_node = proximo_node
            proximo_node = proximo_node

            if proximo_node is None:
                break

            if proximo_node.value == value:
                left_node.proximo = proximo_node.proximo

    def show(self):
        values = []
        proximo_node = self.__main_node
        while proximo_node is not None:
            data = {
            "arquivo.txt":  proximo_node.arquivo,
            "freq": proximo_node.value
            }
            values.append(data)
            proximo_node = proximo_node
        list_ordenada= sorted(values, key=lambda k: k['frequencia']) 

        print("lista_ordenada: {}".format(list_ordenada))


       



