from binarytree import build 
from bst import BST  

keys = [
{1: ["bola", "arq1.txt"]},
{2: ["casa", "arq1.txt"]},
{2: ["casa", "arq2.txt"]},
{1: ["bola", "arq1.txt"]},
{3: ["dado", "arq1.txt"]},
{3: ["dado", "arq1.txt"]},
{3: ["dado", "arq2.txt"]},
{3: ["dado", "arq3.txt"]},
{3: ["dado", "arq2.txt"]},
{4: ["arvore", "arq1.txt"]},
{4: ["arvore", "arq2.txt"]}]

  
# List of nodes 
nodes =[min(p.keys()) for p in keys]
bst = BST()
[bst.insert(value ) for value in nodes ]  

binary_tree = build(nodes) 
print('Arvore :\n', 
      binary_tree) 

menu = str(input("Entre com os termos a ser pesquisados (separados por espaço): "))
  #menu = "dado"
for termo in menu.split():
    print("-"*20, termo, "-"*20)
    for p in keys:
      itens = list(p.values())[0]
      if itens[0] == termo:
        chave = min(p.keys())
        node = bst.search(chave)
        value = {"Termo":termo, "file":itens[1], "Chave Arvore":chave,"Node Value":node.value}
        print(value)
  
 
    


